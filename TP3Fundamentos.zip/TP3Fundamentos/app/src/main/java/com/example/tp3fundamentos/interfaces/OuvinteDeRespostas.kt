package com.example.tp3fundamentos.interfaces

interface OuvinteDeRespostas {
    fun onAnswerSubmit(Resposta: Int)
}