package com.example.tp3fundamentos

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.tp3fundamentos.databinding.ActivityQuestoesBinding
import com.example.tp3fundamentos.databinding.ActivityResultadoBinding

class ResultadoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityResultadoBinding

    var nome =""
    var resultado = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityResultadoBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        nome = intent.getStringExtra(MainActivity.NOME)?:""
        resultado = intent.getStringExtra(QuestoesActivity.RESULTADO)?:""

        binding.nomeResultado.text = nome
        binding.textoResultado.text = resultado
    }
}