package com.example.tp3fundamentos

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.tp3fundamentos.databinding.ActivityQuestoesBinding
import com.example.tp3fundamentos.interfaces.OuvinteDeRespostas

class QuestoesActivity : AppCompatActivity(), OuvinteDeRespostas {

    private lateinit var binding: ActivityQuestoesBinding

    val listaRespostas = mutableListOf<Int>()

    var nome =""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityQuestoesBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        nome = intent.getStringExtra(MainActivity.NOME)?:""
    }

    override fun onAnswerSubmit(resposta: Int) {
        listaRespostas.add(resposta)
       // binding.tvTitulo.text = "Questão ${listaRespostas.size + 1} / 9"
        if(listaRespostas.size == 9){
            concluirQuestionario()
        }else{
            binding.tvTitulo.text = "Questão ${listaRespostas.size + 1} / 9"
        }
    }

    fun concluirQuestionario(){
        var textoEnviado = "Resultado de $nome : \n"
        if(listaRespostas.sum() < 15){
            textoEnviado += "Você tem um perfil conservador"
        }else if (listaRespostas.sum() > 36){
            textoEnviado += "Você tem um perfil Arrojado"
        } else{
            textoEnviado += "Você tem um perfil Moderado"
        }

        val intentResposta = Intent(this, ResultadoActivity::class.java)
        intentResposta.putExtra(MainActivity.NOME, nome)
        intentResposta.putExtra(RESULTADO, textoEnviado)
        startActivity(intentResposta)
    }

    companion object{
        val RESULTADO = "Resultado"
    }
}